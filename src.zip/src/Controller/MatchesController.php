<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Matches Controller
 *
 * @property \App\Model\Table\MatchesTable $Matches
 *
 * @method \App\Model\Entity\Match[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MatchesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {

        $today = date('Y-m-d');
        $this->Matches->updateAll([
            'Matches.status' => '2'
        ], [
            'Matches.match_date <' => $today
        ]);

        $this->paginate = [
            'contain' => ['HostTeams', 'OpponentTeams']
        ];
        $matches = $this->paginate($this->Matches);

        $this->set(compact('matches'));
    }

    /**
     * View method
     *
     * @param string|null $id Match id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->loadModel('MatchDetails');
        $this->MatchDetails->deleteAll(
            array(
                "MatchDetails.bowler" => ''
            )
        );
        $match = $this->Matches->get($id, [
            'contain' => ['HostTeams.Players', 'OpponentTeams.Players', 'MatchDetails']
        ]);
        $match_details = $this->MatchDetails->find()->where(['match_id' => $id])->first();
        if($match_details) {
            $bowling_team_id = $match_details->bowling_team_id;
            $batting_team_id = $match_details->batting_team_id;
            $this->loadModel('Teams');

            $bowling_team = $this->Teams->find()->where(['id' => $bowling_team_id])->first();
            $batting_team = $this->Teams->find()->where(['id' => $batting_team_id])->first();
            $this->set(array('match' => $match, 'bowling_team' => $bowling_team->name, 'batting_team' => $batting_team->name));
        }

        else{
            $this->set('match', $match);
        }
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $match = $this->Matches->newEntity();
        if ($this->request->is('post')) {
            $match = $this->Matches->patchEntity($match, $this->request->getData());
            if ($this->Matches->save($match)) {

                $this->Flash->success(__('The match has been saved.'));

                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(__('The match could not be saved. Please, try again.'));
        }
        $hostTeams = $this->Matches->HostTeams->find('list', ['limit' => 200]);
        $opponentTeams = $this->Matches->OpponentTeams->find('list', ['limit' => 200]);
        $this->set(compact('match', 'hostTeams', 'opponentTeams'));

    }

    /**
     * Edit method
     *
     * @param string|null $id Match id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $match = $this->Matches->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {

            $match = $this->Matches->patchEntity($match, $this->request->getData());
            if ($this->Matches->save($match)) {
                $this->Flash->success(__('The match has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The match could not be saved. Please, try again.'));
        }
        $hostTeams = $this->Matches->HostTeams->find('list', ['limit' => 200]);
        $opponentTeams = $this->Matches->OpponentTeams->find('list', ['limit' => 200]);
        $this->set(compact('match', 'hostTeams', 'opponentTeams'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Match id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $match = $this->Matches->get($id);
        if ($this->Matches->delete($match)) {
            $this->Flash->success(__('The match has been deleted.'));
        } else {
            $this->Flash->error(__('The match could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function live($id = null)
    {
        $match = $this->Matches->get($id, [
            'contain' => ['HostTeams.Players', 'OpponentTeams.Players', 'MatchDetails.BattingTeams.Players', 'MatchDetails.BowlingTeams.Players']
        ]);
        $this->set(compact('match'));
        $this->loadModel('MatchDetails');
        $md = $this->MatchDetails->newEntity($this->request->getData());
        if ($this->request->is(['patch', 'post', 'put'])) {
            $md->match_id = $id;
            $md = $this->MatchDetails->patchEntity($md, $this->request->getData());
            if ($this->MatchDetails->save($md)) {
                return $this->redirect(['action' => 'liveMatch',$id, $this->request->data(['inings']), $this->request->data(['batting_team_id']), $this->request->data(['bowling_team_id'])]);
            }
        }
        $this->set(compact('md'));

    }
    public function liveMatch($id =null, $inings = null, $batting_team_id = null, $bowling_team_id = null){
        $match = $this->Matches->get($id, [
            'contain' => ['HostTeams.Players', 'OpponentTeams.Players', 'MatchDetails.BattingTeams.Players', 'MatchDetails.BowlingTeams.Players']
        ]);
        $this->set(compact('match'));
        $this->loadModel('MatchDetails');
        $match_details_inings = $this->MatchDetails->find()->contain(['BattingTeams.Players', 'BowlingTeams.Players'])->first();
        $this->set(compact('match_details_inings'));
        $this->set('inings', $inings);
        $i=0;
        $m=8;
        if (!empty($match_details_inings)) {
            if ($this->request->is(['patch', 'post', 'put'])) {
                foreach($this->request->getData(['bowler']) as $key1 => $bowler) {
                    foreach($this->request->getData(['batsman']) as $key2 => $batsman)
                        if($key1 == $key2){
                        if (!empty($bowler) && !empty($batsman)) {
                               $md = $this->MatchDetails->newEntity();
                               $md->match_id = $id;
                               $md->inings = $inings;
                               $md->inings_status= 'running';
                               $md->batting_team_id = $batting_team_id;
                               $md->bowling_team_id = $bowling_team_id;
                               foreach($this->request->getData() as $key3 => $value3){
                                   foreach($value3 as $key4 => $value4){
                                       if($key1 == $key4){
                                           if($key3 == 'bowler'){
                                               $md->bowler = $value4;
                                           }
                                           if($key3 == 'bowl'){
                                               $md->bowl = $value4;
                                           }
                                           if($key3 == 'wicket'){
                                               $md->wicket = $value4;
                                           }
                                           if($key3 == 'batsman'){
                                               $md->batsman = $value4;
                                           }
                                           if($key3 == 'bat'){
                                               $md->bat = $value4;
                                           }
                                           if($key3 == 'run'){
                                               $md->run = $value4;
                                           }
                                           if($key3 == 'summery_for_bowler'){
                                               $md->summery_for_bowler = $value4;
                                           }
                                           if($key3 == 'summery_for_batsman'){
                                               $md->summery_for_batsman = $value4;
                                           }
                                       }
                                   }
                                   $i++;
                                   if($i == $m){
                                       $this->MatchDetails->save($md);
                                       $m = $i+$m;
                                   }
                               }

                        }
                    }
                }
                $this->MatchDetails->deleteAll(
                    array(
                        "MatchDetails.bowler" => ''
                    )
                );
                return $this->redirect(['action' => 'view', $id]);
            }

            }
        }

        public function finishInings($id = null, $inings = null){
            $this->loadModel('MatchDetails');
            $this->MatchDetails->updateAll(array('inings_status' => 'closed'), array('AND' => array('MatchDetails.match_id' => $id,'MatchDetails.inings' => $inings)));
            $this->Flash->success(__('inings #{0} has been closed.',$inings));
            return $this->redirect(['action' => 'live', $id]);
        }




}
