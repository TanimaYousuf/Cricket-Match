<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MatchDetails Controller
 *
 * @property \App\Model\Table\MatchDetailsTable $MatchDetails
 *
 * @method \App\Model\Entity\MatchDetail[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MatchDetailsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Matches', 'BowlingTeams', 'BattingTeams']
        ];
        $matchDetails = $this->paginate($this->MatchDetails);

        $this->set(compact('matchDetails'));
    }

    /**
     * View method
     *
     * @param string|null $id Match Detail id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $matchDetail = $this->MatchDetails->get($id, [
            'contain' => ['Matches', 'BowlingTeams', 'BattingTeams']
        ]);

        $this->set('matchDetail', $matchDetail);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $matchDetail = $this->MatchDetails->newEntity();
        if ($this->request->is('post')) {
            $matchDetail = $this->MatchDetails->patchEntity($matchDetail, $this->request->getData());
            if ($this->MatchDetails->save($matchDetail)) {
                $this->Flash->success(__('The match detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The match detail could not be saved. Please, try again.'));
        }
        $matches = $this->MatchDetails->Matches->find('list', ['limit' => 200]);
        $bowlingTeams = $this->MatchDetails->BowlingTeams->find('list', ['limit' => 200]);
        $battingTeams = $this->MatchDetails->BattingTeams->find('list', ['limit' => 200]);
        $this->set(compact('matchDetail', 'matches', 'bowlingTeams', 'battingTeams'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Match Detail id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $matchDetail = $this->MatchDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $matchDetail = $this->MatchDetails->patchEntity($matchDetail, $this->request->getData());
            if ($this->MatchDetails->save($matchDetail)) {
                $this->Flash->success(__('The match detail has been saved.'));

                return $this->redirect(['controller' => 'Matches','action' => 'view', $matchDetail->match_id]);
            }
            $this->Flash->error(__('The match detail could not be saved. Please, try again.'));
        }
        $matches = $this->MatchDetails->Matches->find('list', ['limit' => 200]);
        $bowlingTeams = $this->MatchDetails->BowlingTeams->find('list', ['limit' => 200]);
        $battingTeams = $this->MatchDetails->BattingTeams->find('list', ['limit' => 200]);
        $this->set(compact('matchDetail', 'matches', 'bowlingTeams', 'battingTeams'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Match Detail id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null, $md = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $matchDetail = $this->MatchDetails->get($id);
        if ($this->MatchDetails->delete($matchDetail)) {
            $this->Flash->success(__('The match detail has been deleted.'));
        } else {
            $this->Flash->error(__('The match detail could not be deleted. Please, try again.'));
        }

        return $this->redirect([ 'controller' => 'Matches','action' => 'view', $md]);
    }
}
