<?php
/**
 * Created by PhpStorm.
 * User: tanima
 * Date: 8/8/2019
 * Time: 11:23 AM
 */
namespace ORM\Query;
namespace App\Controller;


class HomeController  extends AppController
{
    public function index(){
        $this->loadModel('Users');
        $today = date('Y-m-d');
        $users = $this->Users->find('all');
        $count = $users->count();
        $this->loadModel('Matches');
        $result = $this->Matches->find('all', array('conditions' => array('Matches.match_date >=' => $today)));
        $matchCount = $result->count();
        $this->set('matches', $matchCount);
        $this->set('count', $count);

    }
}
