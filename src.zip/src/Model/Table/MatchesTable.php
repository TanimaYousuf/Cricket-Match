<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Matches Model
 *
 * @property \App\Model\Table\HostTeamsTable&\Cake\ORM\Association\BelongsTo $HostTeams
 * @property \App\Model\Table\OpponentTeamsTable&\Cake\ORM\Association\BelongsTo $OpponentTeams
 * @property \App\Model\Table\MatchDetailsTable&\Cake\ORM\Association\HasMany $MatchDetails
 *
 * @method \App\Model\Entity\Match get($primaryKey, $options = [])
 * @method \App\Model\Entity\Match newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Match[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Match|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Match saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Match patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Match[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Match findOrCreate($search, callable $callback = null, $options = [])
 */
class MatchesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('matches');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('HostTeams', [
            'foreignKey' => 'host_team_id',
            'className' => 'Teams',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('OpponentTeams', [
            'foreignKey' => 'opponent_team_id',
            'className' => 'Teams',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('MatchDetails', [
            'foreignKey' => 'match_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->date('match_date')
            ->requirePresence('match_date', 'create')
            ->notEmptyDate('match_date');

        $validator
            ->time('match_time')
            ->requirePresence('match_time', 'create')
            ->notEmptyTime('match_time');

        $validator
            ->scalar('status')
            ->requirePresence('status', 'create')
            ->notEmptyString('status');

        $validator->add('opponent_team_id', 'custom', [
            'rule' => function ($value, $context) {
                if($context['data']['host_team_id'] == $context['data']['opponent_team_id']) {
                    return false;
                } else {
                    return true;
                }
            },
            'message' => 'Two teams can not be same'
        ]);
        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['host_team_id'], 'HostTeams'));
        $rules->add($rules->existsIn(['opponent_team_id'], 'OpponentTeams'));

        return $rules;
    }
}
