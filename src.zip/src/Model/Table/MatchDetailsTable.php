<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * MatchDetails Model
 *
 * @property \App\Model\Table\MatchesTable&\Cake\ORM\Association\BelongsTo $Matches
 * @property \App\Model\Table\BowlingTeamsTable&\Cake\ORM\Association\BelongsTo $BowlingTeams
 * @property \App\Model\Table\BattingTeamsTable&\Cake\ORM\Association\BelongsTo $BattingTeams
 *
 * @method \App\Model\Entity\MatchDetail get($primaryKey, $options = [])
 * @method \App\Model\Entity\MatchDetail newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MatchDetail[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MatchDetail|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MatchDetail saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MatchDetail patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MatchDetail[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MatchDetail findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class MatchDetailsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('match_details');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Matches', [
            'foreignKey' => 'match_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('BattingTeams', [
            'foreignKey' => 'batting_team_id',
            'className' => 'Teams',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('BowlingTeams', [
            'foreignKey' => 'bowling_team_id',
            'className' => 'Teams',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');


        $validator->add('bowling_team_id', 'custom', [
            'rule' => function ($value, $context) {
                if($context['data']['batting_team_id'] == $context['data']['bowling_team_id']) {
                    return false;
                } else {
                    return true;
                }
            },
            'message' => 'Two teams can not be same'
        ]);

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['match_id'], 'Matches'));
        $rules->add($rules->existsIn(['bowling_team_id'], 'BowlingTeams'));
        $rules->add($rules->existsIn(['batting_team_id'], 'BattingTeams'));

        return $rules;
    }
}
