<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MatchDetail Entity
 *
 * @property int $id
 * @property int $match_id
 * @property string $inings
 * @property int $bowling_team_id
 * @property int $batting_team_id
 * @property string $inings_status
 * @property int $bowl
 * @property int $wicket
 * @property int $bat
 * @property int $run
 * @property string $summery_for_bowler
 * @property string $summery_for_batsman
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $updated
 *
 * @property \App\Model\Entity\Match $match
 * @property \App\Model\Entity\BowlingTeam $bowling_team
 * @property \App\Model\Entity\BattingTeam $batting_team
 */
class MatchDetail extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'match_id' => true,
        'inings' => true,
        'bowling_team_id' => true,
        'batting_team_id' => true,
        'inings_status' => true,
        'bowler' => true,
        'bowl' => true,
        'wicket' => true,
        'batsman' => true,
        'bat' => true,
        'run' => true,
        'summery_for_bowler' => true,
        'summery_for_batsman' => true,
        'created' => true,
        'updated' => true,
        'match' => true,
        'batting_team' => true,
        'bowling_team' => true,
        'team' => true
    ];
}
